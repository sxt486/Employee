package com.example.new_pro.Repository;

import com.example.new_pro.model.Payslip;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface PayslipRepository extends JpaRepository<Payslip, Long> {
    Optional<Payslip> findByEmployeeId(Long employeeId);
//    List<Payslip> findByEmployeeId(Long employeeId);
}
