package com.example.new_pro.Service;

import com.example.new_pro.model.Employee;
import com.example.new_pro.model.Payslip;
import com.example.new_pro.model.Tax;
import com.example.new_pro.Repository.EmployeeRepository;
import com.example.new_pro.Repository.PayslipRepository;
import com.example.new_pro.Repository.EmployeeTaxRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TaxService {

    @Autowired
    private EmployeeTaxRepository taxRepository;

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private PayslipRepository salaryRepository;

    public Tax computeYearlyTax(Long employeeId) {


        // Step 1: Fetch employee details
        Employee employee = employeeRepository.findById(employeeId)
                .orElseThrow(() -> new RuntimeException("Employee not found"));

        // Step 2: Fetch salary details for the employee
        Payslip salary = salaryRepository.findByEmployeeId(employeeId)
                .orElseThrow(() -> new RuntimeException("Salary details not found for the employee"));

        System.out.println("Gross"+salary.getGrossPay());

        // Step 3: Get the gross annual salary from the salary table

        Double grossSalary = salary.getGrossPay()*12;


        // Step 4: Initialize the yearly tax variable
        Double yearlyTax = 0.0;

        // Step 5: Apply standard tax slabs for calculation
        if (grossSalary <= 250000) {
            yearlyTax = 0.0; // No tax for income up to ₹2,50,000
        } else if (grossSalary <= 500000) {
            yearlyTax = (grossSalary - 250000) * 0.05; // 5% tax for income between ₹2,50,001 and ₹5,00,000
        } else if (grossSalary <= 1000000) {
            yearlyTax = (500000 - 250000) * 0.05; // 5% for second slab
            yearlyTax += (grossSalary - 500000) * 0.20; // 20% for income between ₹5,00,001 and ₹10,00,000
        } else {
            yearlyTax = (500000 - 250000) * 0.05; // 5% for second slab
            yearlyTax += (1000000 - 500000) * 0.20; // 20% for third slab
            yearlyTax += (grossSalary - 1000000) * 0.30; // 30% for income above ₹10,00,000
        }

        // Step 6: Create a new Tax object and save it in the database
        Tax tax = new Tax();
        tax.setEmployee(employee);
        tax.setTaxAmount(yearlyTax);
        // Step 7: Return the saved tax object
        return taxRepository.save(tax);
    }
}