package com.example.new_pro.Service;

import com.example.new_pro.model.Employee;
import com.example.new_pro.model.Payslip;
import com.example.new_pro.Repository.EmployeeRepository;
import com.example.new_pro.Repository.PayslipRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.List;
import java.util.Optional;
@Service
public class EmployeeServicePaySlip {

    @Autowired
    private PayslipRepository salaryRepository;

    @Autowired
    private EmployeeRepository employeeRepository;

    public Payslip getSalaryById(Long employeeId) {
        Optional<Payslip> salaryOptional = salaryRepository.findByEmployeeId(employeeId);
        return salaryOptional.orElseThrow(() -> new RuntimeException("Salary not found for Employee ID: " + employeeId));
    }


    public Payslip generateMonthlyPaycheck(Long employeeId) {
        Employee employee = employeeRepository.findById(employeeId).orElseThrow(() -> new RuntimeException("Employee not found"));

        Double grossPay = employee.getBasicSalary() + employee.getHra() + employee.getMedicalAllowance() + employee.getConveyance();
        Double deductions = employee.getPf() + employee.getProfessionalTax();
        Double netPay = grossPay - deductions;

        Payslip salary = new Payslip();
        salary.setEmployee(employee);
        salary.setGrossPay(grossPay);
        salary.setNetPay(netPay);

        return salaryRepository.save(salary);
    }

}

