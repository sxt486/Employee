package com.example.new_pro.Service;

import com.example.new_pro.DTO.EmployeeDTO;
import com.example.new_pro.model.Employee;
import com.example.new_pro.Repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    public Employee createOrUpdateEmployee(EmployeeDTO employeeDTO) {
        Employee employee = new Employee();
        // Map DTO to Entity
        employee.setName(employeeDTO.getName());
        employee.setDepartment(employeeDTO.getDepartment());
        employee.setBasicSalary(employeeDTO.getBasicSalary());
        employee.setHra(employeeDTO.getHra());
        employee.setMedicalAllowance(employeeDTO.getMedicalAllowance());
        employee.setConveyance(employeeDTO.getConveyance());
        employee.setRelocationTax(employeeDTO.getRelocationTax());
        employee.setPf(employeeDTO.getPf());
        employee.setProfessionalTax(employeeDTO.getProfessionalTax());

        return employeeRepository.save(employee);
    }
    // Get employee by ID
    public Employee getEmployeeById(Long id) {
        return employeeRepository.findById(id).orElse(null);
    }

    // Get all employees
    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    public void deleteEmployee(Long id) {
        employeeRepository.deleteById(id);
    }


}