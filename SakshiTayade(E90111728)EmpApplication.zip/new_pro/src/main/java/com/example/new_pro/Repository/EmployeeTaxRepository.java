

package com.example.new_pro.Repository;


import com.example.new_pro.model.Tax;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EmployeeTaxRepository extends JpaRepository<Tax, Long> {
}


