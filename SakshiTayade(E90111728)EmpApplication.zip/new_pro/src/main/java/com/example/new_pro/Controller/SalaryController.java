package com.example.new_pro.Controller;

import com.example.new_pro.model.Payslip;
import com.example.new_pro.Service.EmployeeServicePaySlip;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/salary")
public class SalaryController {

    @Autowired
    private EmployeeServicePaySlip salaryService;

    @PostMapping("/generate/{employeeId}")
    public ResponseEntity<Payslip> generatePaycheck(@PathVariable Long employeeId) {
        Payslip salary = salaryService.generateMonthlyPaycheck(employeeId);
        return ResponseEntity.ok(salary);
    }

    @GetMapping("/{employeeId}")
    public ResponseEntity<Payslip>getSalaryById(@PathVariable Long employeeId){
        Payslip salary = salaryService.generateMonthlyPaycheck(employeeId);
        return ResponseEntity.ok(salary);
    }

}