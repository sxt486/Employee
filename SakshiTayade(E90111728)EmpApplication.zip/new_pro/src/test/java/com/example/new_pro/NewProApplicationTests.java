package com.example.new_pro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class NewProApplicationTests {

	@Test
	void contextLoads() {
	}

}
