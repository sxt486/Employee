package com.example.new_pro;




import com.example.new_pro.Controller.EmployeeController;
import com.example.new_pro.Controller.SalaryController;
import com.example.new_pro.Controller.TaxController;
import com.example.new_pro.DTO.EmployeeDTO;
import com.example.new_pro.Service.EmployeeService;
import com.example.new_pro.Service.EmployeeServicePaySlip;
import com.example.new_pro.Service.TaxService;
import com.example.new_pro.model.Employee;
import com.example.new_pro.model.Payslip;
import com.example.new_pro.model.Tax;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
        import static org.mockito.Mockito.*;

@Nested
class Controllertest {

    @InjectMocks
    private EmployeeController employeeController;

    @InjectMocks
    private SalaryController salaryController;

    @InjectMocks
    private TaxController taxController;

    @Mock
    private EmployeeService employeeService;

    @Mock
    private EmployeeServicePaySlip salaryService;

    @Mock
    private TaxService taxService;

    private Employee employee;
    private Payslip payslip;
    private Tax tax;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        // Setting up Employee
        employee = new Employee();
        employee.setId(1L);
        employee.setName("John Doe");

        // Setting up Payslip
        payslip = new Payslip();
        payslip.setEmployee(employee);
        payslip.setGrossPay(700000.0);
        payslip.setNetPay(650000.0);

        // Setting up Tax
        tax = new Tax();
        tax.setEmployee(employee);
        tax.setTaxAmount(90000.0);
    }

    // Tests for EmployeeController

    @Test
    void testCreateOrUpdateEmployee() {
        EmployeeDTO employeeDTO = new EmployeeDTO(); // Assume EmployeeDTO is set properly
        when(employeeService.createOrUpdateEmployee(any(EmployeeDTO.class))).thenReturn(employee);

        ResponseEntity<Employee> response = employeeController.createOrUpdateEmployee(employeeDTO);

        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("John Doe", response.getBody().getName());
        verify(employeeService, times(1)).createOrUpdateEmployee(any(EmployeeDTO.class));
    }

    @Test
    void testDeleteEmployee() {
        doNothing().when(employeeService).deleteEmployee(1L);

        ResponseEntity<Void> response = employeeController.deleteEmployee(1L);

        assertEquals(HttpStatus.NO_CONTENT, response.getStatusCode());
        verify(employeeService, times(1)).deleteEmployee(1L);
    }

    @Test
    void testGetEmployeeById() {
        when(employeeService.getEmployeeById(1L)).thenReturn(employee);

        ResponseEntity<Employee> response = employeeController.getEmployeeById(1L);

        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("John Doe", response.getBody().getName());
        verify(employeeService, times(1)).getEmployeeById(1L);
    }

    @Test
    void testGetAllEmployees() {
        List<Employee> employees = Arrays.asList(employee);
        when(employeeService.getAllEmployees()).thenReturn(employees);

        ResponseEntity<List<Employee>> response = employeeController.getAllEmployees();

        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(1, response.getBody().size());
        verify(employeeService, times(1)).getAllEmployees();
    }

    // Tests for SalaryController

    @Test
    void testGeneratePaycheck() {
        when(salaryService.generateMonthlyPaycheck(1L)).thenReturn(payslip);

        ResponseEntity<Payslip> response = salaryController.generatePaycheck(1L);

        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(700000.0, response.getBody().getGrossPay());
        verify(salaryService, times(1)).generateMonthlyPaycheck(1L);
    }

    @Test
    void testGetSalaryById() {
        when(salaryService.getSalaryById(1L)).thenReturn(payslip);

        ResponseEntity<Payslip> response = salaryController.getSalaryById(1L);

        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(700000.0, response.getBody().getGrossPay());
        verify(salaryService, times(1)).getSalaryById(1L);
    }




}
