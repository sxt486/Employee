package com.example.new_pro;
import com.example.new_pro.Repository.EmployeeRepository;
import com.example.new_pro.Repository.PayslipRepository;
import com.example.new_pro.Repository.EmployeeTaxRepository;
import com.example.new_pro.Service.EmployeeService;
import com.example.new_pro.Service.EmployeeServicePaySlip;
import com.example.new_pro.Service.TaxService;
import com.example.new_pro.model.Employee;
import com.example.new_pro.model.Payslip;
import com.example.new_pro.model.Tax;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
        import static org.mockito.Mockito.*;

class ServiceTest {

    @InjectMocks
    private EmployeeService employeeService;

    @InjectMocks
    private EmployeeServicePaySlip employeeServicePaySlip;

    @InjectMocks
    private TaxService taxService;

    @Mock
    private EmployeeRepository employeeRepository;

    @Mock
    private PayslipRepository payslipRepository;

    @Mock
    private EmployeeTaxRepository taxRepository;

    private Employee employee;
    private Payslip payslip;
    private Tax tax;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        // Setting up Employee
        employee = new Employee();
        employee.setId(1L);
        employee.setName("John Doe");
        employee.setBasicSalary(5000.0);
        employee.setHra(1000.0);
        employee.setMedicalAllowance(500.0);
        employee.setPf(300.0);
        employee.setProfessionalTax(200.0);

        // Setting up Payslip
        payslip = new Payslip();
        payslip.setEmployee(employee);
        payslip.setGrossPay(700000.0); // Example annual gross salary
        payslip.setNetPay(650000.0); // Example net salary

        // Setting up Tax
        tax = new Tax();
        tax.setEmployee(employee);
        tax.setTaxAmount(90000.0); // Example tax amount
    }

    // Tests for EmployeeService

    @Test
    void testCreateOrUpdateEmployee() {
        when(employeeRepository.save(any(Employee.class))).thenReturn(employee);

        Employee result = employeeService.createOrUpdateEmployee(employee);

        assertNotNull(result);
        assertEquals("John Doe", result.getName());
        verify(employeeRepository, times(1)).save(any(Employee.class));
    }

    @Test
    void testGetEmployeeById() {
        when(employeeRepository.findById(1L)).thenReturn(Optional.of(employee));

        Employee result = employeeService.getEmployeeById(1L);

        assertNotNull(result);
        assertEquals("John Doe", result.getName());
        verify(employeeRepository, times(1)).findById(1L);
    }

    // Tests for PayslipService

    @Test
    void testGenerateMonthlyPaycheck() {
        when(employeeRepository.findById(1L)).thenReturn(Optional.of(employee));
        when(payslipRepository.save(any(Payslip.class))).thenReturn(payslip);

        Payslip result = employeeServicePaySlip.generateMonthlyPaycheck(1L);

        assertNotNull(result);
        assertEquals(700000.0, result.getGrossPay());
        assertEquals(650000.0, result.getNetPay());
        verify(employeeRepository, times(1)).findById(1L);
        verify(payslipRepository, times(1)).save(any(Payslip.class));
    }

    @Test
    void testGetSalaryById() {
        when(payslipRepository.findByEmployeeId(1L)).thenReturn(Optional.of(payslip));

        Payslip result = employeeServicePaySlip.getSalaryById(1L);

        assertNotNull(result);
        assertEquals(700000.0, result.getGrossPay());
        assertEquals(650000.0, result.getNetPay());
        verify(payslipRepository, times(1)).findByEmployeeId(1L);
    }

    // Tests for TaxService

    @Test
    void testComputeYearlyTax() {
        when(employeeRepository.findById(1L)).thenReturn(Optional.of(employee));
        when(payslipRepository.findByEmployeeId(1L)).thenReturn(Optional.of(payslip));
        when(taxRepository.save(any(Tax.class))).thenReturn(tax);

        Tax result = taxService.computeYearlyTax(1L);

        assertNotNull(result);
        assertEquals(90000.0, result.getTaxAmount());
        verify(employeeRepository, times(1)).findById(1L);
        verify(payslipRepository, times(1)).findByEmployeeId(1L);
        verify(taxRepository, times(1)).save(any(Tax.class));
    }

    @Test
    void testComputeYearlyTax_EmployeeNotFound() {
        when(employeeRepository.findById(1L)).thenReturn(Optional.empty());

        Exception exception = assertThrows(RuntimeException.class, () -> {
            taxService.computeYearlyTax(1L);
        });

        assertEquals("Employee not found", exception.getMessage());
        verify(employeeRepository, times(1)).findById(1L);
        verify(payslipRepository, never()).findByEmployeeId(1L);
        verify(taxRepository, never()).save(any(Tax.class));
    }

    @Test
    void testComputeYearlyTax_PayslipNotFound() {
        when(employeeRepository.findById(1L)).thenReturn(Optional.of(employee));
        when(payslipRepository.findByEmployeeId(1L)).thenReturn(Optional.empty());

        Exception exception = assertThrows(RuntimeException.class, () -> {
            taxService.computeYearlyTax(1L);
        });

        assertEquals("Salary details not found for the employee", exception.getMessage());
        verify(employeeRepository, times(1)).findById(1L);
        verify(payslipRepository, times(1)).findByEmployeeId(1L);
        verify(taxRepository, never()).save(any(Tax.class));
    }
}
